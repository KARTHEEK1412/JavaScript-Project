//Getting a resource store in localstorage
// const submit = document.querySelector(".submit-button");

const creation = function (para, arg) {
  let para1 = para;
  var task = para1;
  var list_el = document.querySelector("#tasks");
  var task_el = document.createElement("div");
  task_el.classList.add("task");
  var task_content_el = document.createElement("div");
  task_content_el.classList.add("content");
  task_content_el.innerHTML = `<p>${para1}</p>`;
  task_el.appendChild(task_content_el);
  var task_input_el = document.createElement("input");
  task_input_el.classList.add("text");
  task_input_el.type = "text";
  // task_input_el.value = prompt("please enter your name");
  task_input_el.setAttribute("readonly", "readonly");
  task_content_el.appendChild(task_input_el);
  var task_actions_el = document.createElement("div");
  task_actions_el.classList.add("actions");
  var task_edit_el = document.createElement("button");
  task_edit_el.classList.add(`"edit-${arg}"`);
  task_edit_el.innerHTML = "Edit";
  var task_delete_el = document.createElement("button");
  task_delete_el.classList.add(`"delete-${arg}"`);
  task_delete_el.innerHTML = "Delete";
  task_actions_el.appendChild(task_edit_el);
  task_actions_el.appendChild(task_delete_el);
  task_el.appendChild(task_actions_el);

  list_el.appendChild(task_el);

  task_edit_el.addEventListener("click", () => {
    let editname = task_edit_el.className;
    let editname1 = editname.slice(6);
    let cls1 = editname1[0];
    if (task_edit_el.innerText.toLowerCase() == "edit") {
      task_input_el.removeAttribute("readonly");
      task_input_el.focus();
      task_edit_el.innerText = "Save";
      if (task_input_el.value) {
        var inputvalue = task_input_el.value;
        // task_content_el.innerText = inputvalue;

        fetch(`https://jsonplaceholder.typicode.com/users/${cls1}`, {
          method: "PATCH",
          body: JSON.stringify({
            username: inputvalue,
          }),
          headers: {
            "Content-type": "application/json; charset=UTF-8",
          },
        })
          .then((response) => {
            console.log(task_content_el);
            task_content_el.firstChild.innerText = inputvalue;
            task_input_el.setAttribute("readonly", "readonly");
            task_input_el.value = "";
          })
          .then((json) => {});
      }
    } else {
      task_input_el.setAttribute("readonly", "readonly");
      task_edit_el.innerText = "Edit";
    }
  });
  task_delete_el.addEventListener("click", () => {
    let classname = task_delete_el.className;
    let classname1 = classname.slice(8);
    let cls = classname1[0];
    // list_el.removeChild(task_el);
    fetch(`https://jsonplaceholder.typicode.com/users/${cls}`, {
      method: "DELETE",
    })
      .then((response) => {
        response.json();
      })
      .then((res) => {
        list_el.removeChild(task_el);
        // arr = arr.splice(`${cls}`, `${cls}`);
        // window.localStorage.setItem("data", arr);
        // const text2 = para1;
        // Object.values(y).forEach((val, i) => {
        //   if (text2 == val.username) {
        //     const spliced = y.splice(i, 1);
        //     const newdata1 = window.localStorage.setItem(
        //       "newData1",
        //       JSON.stringify(y)
        //     );
        //   }
        // });
      });
  });
};

const unordered = document.querySelector(".updated-list");
var arr = [];
fetch("https://jsonplaceholder.typicode.com/users")
  .then((response) => response.json())
  .then((json) => {
    window.localStorage.setItem("data", JSON.stringify(json));
    arr = JSON.parse(window.localStorage.getItem("data"));
    arr.forEach((element, index) => {
      creation(`${element.username}`, `${index}`);
    });
  });

function editTask(para) {
  const update1 = {
    name: "Clementina",
  };
  const userid1 = Number(para);
  console.log(userid1);
  fetch(`"https://jsonplaceholder.typicode.com/users/${userid1}"`, {
    method: "PATCH",
    body: JSON.stringify(update1),
    headers: {
      "Content-type": "application/json; charset=UTF-8",
    },
  })
    .then((response) => {})
    .then((json) => {
      //   console.log(json);
    });
}
//for updating new data
const form = document.getElementById("input-form");
form.addEventListener("submit", function (e) {
  e.preventDefault();
  const newdata3 = Array.from(
    document.querySelectorAll("#input-form input")
  ).reduce((acc, input) => ({ ...acc, [input.id]: input.value }), {});
  // console.log(newdata3);
  fetch("https://jsonplaceholder.typicode.com/users", {
    method: "POST",
    body: JSON.stringify(newdata3),
    headers: {
      "Content-type": "application/json; charset=UTF-8",
    },
  }).then((response) => {
    response.json().then((json) => {
      // console.log(json); //json is the input data
      arr = JSON.parse(window.localStorage.getItem("data"));
      arr.push(json);
      window.localStorage.setItem("data", JSON.stringify(arr));
      let [last] = arr.slice(-1);
      creation(`${last.username}`);
      // var markup = `<div class="task"><li class="task1">${last.username}</li> <br>
      //   <div class="actions">
      //   <button onclick = "editTask(${markup})" class="edit">Edit</button>
      //   <button onclick = "deleteTask(${last.username})" class="delete">Delete</button>
      //   </div>
      //   </div> `;
      // document.querySelector("ul").insertAdjacentHTML("beforeend", markup);
    });
  });
});
/*
// updation(newdata);
//assignin the storeed data
var x = window.localStorage.getItem("data"); //datatype string
var y = JSON.parse(x);
// console.log("type of data", typeof y); // data type object
console.log(y);

//patching an data

const patch = function (data) {
  fetch("https://jsonplaceholder.typicode.com/users/11", {
    method: "PATCH",
    body: JSON.stringify(data),
    headers: {
      "Content-type": "application/json; charset=UTF-8",
    },
  })
    .then((response) => {
      response.json();
      // console.log(x);
    })
    .then((json) => {
      //   console.log(json);
    });
};

//data for patch
const patchdata = {
  phone: "1234568858",
};
del_btn.addEventListener("click", function (e) {
    e.preventDefault();
    console.log("delete");
    fetch("https://jsonplaceholder.typicode.com/users/11`", {
      method: "DELETE",
    })
      .then((response) => {
        response.json();
      })
      .then((res) => {
        const text2 = txt2.value;
        Object.values(y).forEach((val, i) => {
          if (text2 == val.username) {
            const spliced = y.splice(i, 1);
            const newdata1 = window.localStorage.setItem(
              "newData1",
              JSON.stringify(y)
            );
          }
        });
      });
  });
//calling the patch function
patch(patchdata);
////*********/ //
//deleting an resource
/*
const del_btn = document.querySelector(".delete");
const delete1 = function () {
  del_btn.addEventListener("click", function (e) {
    e.preventDefault();
    console.log("delete");
    fetch("https://jsonplaceholder.typicode.com/users/11`", {
      method: "DELETE",
    })
      .then((response) => {
        response.json();
      })
      .then((res) => {
        const text2 = txt2.value;
        Object.values(y).forEach((val, i) => {
          if (text2 == val.username) {
            const spliced = y.splice(i, 1);
            const newdata1 = window.localStorage.setItem(
              "newData1",
              JSON.stringify(y)
            );
          }
        });
      });
  });
};
delete1();
//calling the POST
*/
//fetching details in the localstorage
/*Object.values(y).forEach((val, i) => {
  const para = `<p class="about-details">id:${val.id}.<br>
  name:${val.username}.<br>username:${val.username}.<br>email:${
    val.email
  }.<br>address:${Object.values(val.address)}.<br>phone:${
    val.phone
  }.<br>Website:${val.website}.<br>company:${Object.values(val.company)}.</p>`;
  document.querySelector(".details").insertAdjacentHTML("beforeend", para);
});
*/
// const g = document.querySelector(".fetch-details-btn");
// console.log(g);

// document
//   .getElementById("#submit-button")
//   .addEventListener(".click", function (e) {
//     e.preventDefault();
//     const g = document.querySelector(".fetch-details-btn").textContent;
//     console.log(g);
//   });

// function abc(e) {
//   e.preventDefault();
//   let value1 = document.getElementById("fetch-details-btn").textContent;
//   console.log(value1, "abc.com");
// }

// function addChar(e) {
//   console.log("e.target", e);
// }
// const call = function () {
//   const display = `<h3> sorry😑 <br> you entered invalid name</h3>`;
//   document.querySelector(".display").insertAdjacentHTML("beforeend", display);
// };
/*****used for user details */
/******************************** */
// const txt1 = document.getElementById("fetch-details-btn");
// const btn1 = document.getElementById("button1");
// // const out1 = document
// const fun1 = function () {
//   const out1 = txt1.value;
//   //fetching details in the localstorage
//   Object.values(y).forEach((val, i) => {
//     // console.log(val.name);
//     let flag = 0;
//     if (out1 === val.username) {
//       const para = `<p class="about-details">id:${val.id}.<br>
//     name:${val.username}.<br>username:${val.username}.<br>email:${
//         val.email
//       }.<br>address:${Object.values(val.address)}.<br>phone:${
//         val.phone
//       }.<br>Website:${val.website}.<br>company:${Object.values(
//         val.company
//       )}.</p>`;
//       document.querySelector(".details").insertAdjacentHTML("beforeend", para);
//       flag++;
//     }
//     if (flag == 0) {
//       const display = `<h3> sorry😑 <br> you entered invalid name</h3>`;
//       document
//         .querySelector(".display")
//         .insertAdjacentHTML("beforeend", display)
